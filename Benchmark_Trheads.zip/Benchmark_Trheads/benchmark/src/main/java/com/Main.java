package com;

public class Main {

    public static void main(String[] args) {
        OpenPDF openPDF = OpenPDF.getInstance();
        String[] words = openPDF.getWords(); 

        String groupIndex = "0";
         for(int i=0; i<30; i++){
            sequencial(groupIndex,words);
        }   
    }

    private static void sequencial(String groupIndex, String[] words){
        ProcessBenchmark sequencial = new ProcessBenchmark(groupIndex,words);
        System.out.println(sequencial.getTime()+" ms");
    }
}