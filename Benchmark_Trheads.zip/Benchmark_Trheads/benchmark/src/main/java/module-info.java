module com {
    exports com;
    
    requires java.base;
    requires java.desktop;

    requires org.apache.pdfbox;

    requires lombok;
}
